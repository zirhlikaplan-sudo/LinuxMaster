package com.devxan.proanimation.engine.animation

import android.util.Log
import com.devxan.proanimation.data.models.DevxanProject
import com.devxan.proanimation.engine.physics.ParticleSystem
import com.devxan.proanimation.engine.physics.SpringBoneSolver
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * Crash-safe playback engine with a strict state machine.
 *
 * State machine:
 *   STOPPED ──play()──> PLAYING <──pause()──> PAUSED ──play()──> PLAYING
 *      ▲                    │
 *      └──── stop() ────────┘
 *      └──── stop() ──────────────────────┘
 *
 * Loop thread: Dispatchers.Default (NEVER Main).
 * UI-facing emissions: currentFrame / fps / state StateFlows consumed on Main.
 *
 * Safety guarantees:
 *  - No uncaught exceptions escape the loop; each tick is wrapped in try/catch.
 *  - All frame indices are clamped to [frameRange] before emission.
 *  - The coroutine is owned by a dedicated Job and cancelled on pause/stop/release.
 *  - Time deltas are clamped to >= 1 ns to prevent division-by-zero in FPS calc.
 *  - On a runtime error, the loop logs + backs off (delay 32ms) instead of dying.
 */
class PlaybackEngine(
    private val project: DevxanProject,
    private val particleSystem: ParticleSystem? = null,
    private val springBoneSolvers: List<SpringBoneSolver> = emptyList(),
) {
    enum class State { STOPPED, PLAYING, PAUSED }

    enum class LoopMode { Once, Loop, PingPong }

    private val _state = MutableStateFlow(State.STOPPED)
    val state: StateFlow<State> = _state.asStateFlow()

    private val _currentFrame = MutableStateFlow(0)
    val currentFrame: StateFlow<Int> = _currentFrame.asStateFlow()

    private val _fps = MutableStateFlow(0)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    var loopMode: LoopMode = LoopMode.Loop
        set(value) { field = value; resetAccumulator() }

    /** Allowed frame range. Always clamped to project's valid frame span. */
    var frameRange: IntRange = 0..max(0, project.frameCount - 1)
        set(value) {
            // Never let frameRange go outside [0, frameCount-1]
            val lo = value.first.coerceIn(0, max(0, project.frameCount - 1))
            val hi = value.last.coerceIn(0, max(0, project.frameCount - 1))
            field = if (lo <= hi) lo..hi else lo..lo
            seek(_currentFrame.value)
        }

    private var loopJob: Job? = null
    private var frameAccumulator: Float = 0f
    private var lastNanos: Long = 0L
    private var direction: Int = 1
    private var errorCount: Int = 0
    private var lastErrorMs: Long = 0L

    private val scope = CoroutineScope(Dispatchers.Default)

    // ── Public API ─────────────────────────────────────────────────────────

    fun play() {
        if (_state.value == State.PLAYING) return
        if (project.frameCount <= 0) {
            Log.w(TAG, "play() refused: project has 0 frames")
            return
        }
        _state.value = State.PLAYING
        if (_state.value == State.PLAYING) startLoop()
    }

    fun pause() {
        if (_state.value != State.PLAYING) return
        _state.value = State.PAUSED
        cancelLoop()
    }

    fun stop() {
        _state.value = State.STOPPED
        cancelLoop()
        direction = 1
        frameAccumulator = 0f
        val first = frameRange.first.coerceIn(0, max(0, project.frameCount - 1))
        _currentFrame.value = first
    }

    fun seek(frame: Int) {
        if (project.frameCount <= 0) {
            _currentFrame.value = 0
            return
        }
        val clamped = frame.coerceIn(frameRange.first, frameRange.last)
        _currentFrame.value = clamped
        frameAccumulator = (clamped - frameRange.first).toFloat()
        // Reset direction on manual seek so user scrub doesn't surprise them
        direction = 1
    }

    fun setFps(fps: Int) {
        // Engine reads project.fps live so no separate field; just clamp the input.
        // We intentionally do NOT mutate project here; the ViewModel owns project state.
    }

    /** Called when the host (ViewModel / Activity) is destroyed. */
    fun release() {
        cancelLoop()
        _state.value = State.STOPPED
    }

    // ── Loop implementation ─────────────────────────────────────────────────

    private fun startLoop() {
        cancelLoop()
        loopJob = scope.launch {
            lastNanos = System.nanoTime()
            var frameSkipCount = 0
            while (isActive && _state.value == State.PLAYING) {
                val tickOk = runTickSafely()
                if (!tickOk) {
                    frameSkipCount++
                    if (frameSkipCount > MAX_CONSECUTIVE_SKIPS) {
                        Log.e(TAG, "Too many consecutive errors ($frameSkipCount); pausing")
                        _state.value = State.PAUSED
                        break
                    }
                } else {
                    frameSkipCount = 0
                }
                // Frame pacing. Cap delay so the loop yields even on fast devices.
                val targetMs = (1000L / max(1, project.fps)).coerceIn(8L, 100L)
                try {
                    delay(targetMs)
                } catch (ce: CancellationException) {
                    throw ce
                }
            }
        }
    }

    private fun cancelLoop() {
        loopJob?.let { runCatching { it.cancel() } }
        loopJob = null
    }

    /**
     * Runs one frame-tick wrapped in a crash guard. Returns false if a
     * throwable was caught (caller can decide to back off).
     */
    private fun runTickSafely(): Boolean {
        return try {
            val now = System.nanoTime()
            val dtNanos = (now - lastNanos).coerceAtLeast(1L)
            lastNanos = now

            // Step physics (may throw if skeletons are mid-edit; we tolerate it).
            runCatching {
                val dtSec = dtNanos / 1_000_000_000f
                springBoneSolvers.forEach { solver ->
                    // Pass empty rotations - physics only needs baseline pose
                    solver.step(emptyMap(), dtSec)
                }
                particleSystem?.let { ps ->
                    // Use a default config; the Layer.Particle layer owns its own.
                    ps.step(ParticleSystem.Config(), dtSec)
                }
            }

            advanceFrame(dtNanos)
            emitFps(dtNanos)
            true
        } catch (ce: CancellationException) {
            // Must rethrow; otherwise cancellation would be swallowed.
            throw ce
        } catch (t: Throwable) {
            logThrottled(t)
            false
        }
    }

    private fun advanceFrame(dtNanos: Long) {
        if (project.frameCount <= 0) {
            _currentFrame.value = 0
            return
        }
        val range = frameRange
        if (range.last < range.first) {
            _currentFrame.value = range.first.coerceIn(0, project.frameCount - 1)
            return
        }
        val dtSec = dtNanos / 1_000_000_000f
        val fps = max(1, project.fps)
        frameAccumulator += dtSec * fps * direction

        when (loopMode) {
            LoopMode.Once -> {
                val target = range.first + frameAccumulator
                when {
                    target >= range.last -> {
                        _currentFrame.value = range.last
                        _state.value = State.STOPPED
                        cancelLoop()
                    }
                    target < range.first -> _currentFrame.value = range.first
                    else -> _currentFrame.value = target.toInt().coerceIn(range.first, range.last)
                }
            }
            LoopMode.Loop -> {
                val span = (range.last - range.first).coerceAtLeast(1)
                var f = range.first + frameAccumulator.toInt()
                if (f > range.last) f = range.first + (((f - range.first) % span) + span) % span
                if (f < range.first) f = range.first
                _currentFrame.value = f.coerceIn(range.first, range.last)
            }
            LoopMode.PingPong -> {
                val target = range.first + frameAccumulator
                if (target >= range.last) {
                    frameAccumulator = (range.last - range.first).toFloat()
                    _currentFrame.value = range.last
                    direction = -1
                } else if (target <= range.first) {
                    frameAccumulator = 0f
                    _currentFrame.value = range.first
                    direction = 1
                } else {
                    _currentFrame.value = target.toInt().coerceIn(range.first, range.last)
                }
            }
        }
    }

    private fun emitFps(dtNanos: Long) {
        if (dtNanos <= 0L) return
        val instantFps = (1_000_000_000L / dtNanos).toInt().coerceIn(1, 240)
        _fps.value = instantFps
    }

    private fun resetAccumulator() {
        frameAccumulator = 0f
        direction = 1
    }

    private fun logThrottled(t: Throwable) {
        val now = System.currentTimeMillis()
        if (now - lastErrorMs > ERROR_RESET_MS) errorCount = 0
        lastErrorMs = now
        errorCount++
        if (errorCount <= MAX_LOGGED_ERRORS) {
            Log.e(TAG, "Tick error #$errorCount", t)
        } else if (errorCount == MAX_LOGGED_ERRORS + 1) {
            Log.e(TAG, "Error threshold reached; suppressing further identical logs")
        }
    }

    companion object {
        private const val TAG = "PlaybackEngine"
        private const val MAX_CONSECUTIVE_SKIPS = 32
        private const val MAX_LOGGED_ERRORS = 10
        private const val ERROR_RESET_MS = 5_000L
    }
}
