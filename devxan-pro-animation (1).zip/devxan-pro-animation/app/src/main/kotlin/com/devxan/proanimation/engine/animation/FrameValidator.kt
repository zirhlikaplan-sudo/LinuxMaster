package com.devxan.proanimation.engine.animation

import com.devxan.proanimation.data.models.DevxanProject
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.data.models.Skeleton

/**
 * Bounds-checking & null-safety helpers used by the playback loop and the
 * canvas renderer. Every accessor returns either a safe value or null;
 * callers are expected to render a blank frame rather than throw when a
 * null is returned.
 */
object FrameValidator {

    /**
     * Immutable snapshot of what the renderer needs for one frame. Built
     * on the playback thread, consumed on the UI thread.
     */
    data class FrameData(
        val frameIndex: Int,
        val layers: List<Layer>,         // defensive copy
        val skeletons: Map<String, Skeleton>,
        val isBlank: Boolean,
    )

    /**
     * Returns a [FrameData] snapshot of the project for the given frame,
     * clamping the frame index to [0, frameCount-1] and copying mutable
     * collections so the renderer never sees a `ConcurrentModificationException`.
     */
    fun safeFrame(project: DevxanProject, frame: Int): FrameData {
        val lastValid = (project.frameCount - 1).coerceAtLeast(0)
        val clampedFrame = frame.coerceIn(0, lastValid)

        // Defensive copy: avoids ConcurrentModificationException if a layer is
        // added/removed by the UI thread while the renderer is iterating.
        val safeLayers: List<Layer> = synchronized(project.layers) {
            project.layers.toList()
        }
        val safeSkeletons: Map<String, Skeleton> = synchronized(project.skeletons) {
            project.skeletons.toMap()
        }

        val anyVisible = safeLayers.any { runCatching { it.visible }.getOrDefault(false) }
        val isBlank = safeLayers.isEmpty() || !anyVisible

        return FrameData(
            frameIndex = clampedFrame,
            layers = safeLayers,
            skeletons = safeSkeletons,
            isBlank = isBlank,
        )
    }

    /** True if [frame] is within the project's current frame range. */
    fun isFrameInRange(project: DevxanProject, frame: Int): Boolean =
        frame in 0 until project.frameCount

    /** Returns the layer at [index] or null if out of bounds. */
    fun safeLayer(layers: List<Layer>, index: Int): Layer? =
        runCatching { layers.getOrNull(index) }.getOrNull()

    /** Returns the skeleton for [skeletonId] or null if missing. */
    fun safeSkeleton(project: DevxanProject, skeletonId: String?): Skeleton? =
        runCatching { skeletonId?.let { project.skeletons[it] } }.getOrNull()

    /**
     * Coerces a frame value to the project's valid range. Returns 0 if the
     * project has no frames yet.
     */
    fun clampFrame(project: DevxanProject, frame: Int): Int =
        if (project.frameCount <= 0) 0
        else frame.coerceIn(0, project.frameCount - 1)
}
