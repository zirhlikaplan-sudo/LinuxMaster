package com.devxan.proanimation.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.devxan.proanimation.DevxanApplication
import com.devxan.proanimation.data.models.AudioTrackRef
import com.devxan.proanimation.data.models.DevxanProject
import com.devxan.proanimation.data.models.FigureLibrary
import com.devxan.proanimation.data.models.Keyframe
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.data.models.Transform
import com.devxan.proanimation.data.models.Vec2
import com.devxan.proanimation.data.pivot.PivParser
import com.devxan.proanimation.data.pivot.StkParser
import com.devxan.proanimation.engine.animation.AnimationEvaluator
import com.devxan.proanimation.engine.animation.OnionSkinConfig
import com.devxan.proanimation.engine.animation.PlaybackController
import com.devxan.proanimation.engine.animation.PlaybackEngine
import com.devxan.proanimation.engine.audio.AudioEngine
import com.devxan.proanimation.engine.bones.AutoRigger
import com.devxan.proanimation.engine.ik.CcdIkSolver
import com.devxan.proanimation.engine.physics.Environment
import com.devxan.proanimation.engine.physics.ParticleSystem
import com.devxan.proanimation.engine.physics.SpringBoneSolver
import com.devxan.proanimation.engine.project.DxprojSerializer
import com.devxan.proanimation.engine.project.ProjectValidator
import com.devxan.proanimation.engine.undo.Command
import com.devxan.proanimation.engine.undo.PropertyCommand
import com.devxan.proanimation.engine.undo.UndoStack
import com.devxan.proanimation.engine.vector.Primitives
import com.devxan.proanimation.engine.vector.PathBooleanOps
import com.devxan.proanimation.engine.vector.PathSimplifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * Central studio view-model. Holds the active [DevxanProject], the
 * [PlaybackController], [UndoStack], [AudioEngine], [ParticleSystem], and
 * exposes observable state for the Compose UI.
 */
class StudioViewModel(app: Application) : AndroidViewModel(app) {

    private val appRef = app as DevxanApplication
    private val serializer = DxprojSerializer()
    private val validator = ProjectValidator()

    val project: DevxanProject = DevxanProject(
        name = "Untitled Project",
        fps = 24,
        frameCount = 240,
        canvasWidth = 1920, canvasHeight = 1080
    )

    val audioEngine: AudioEngine = appRef.audioEngine
    val undoStack = UndoStack(capacity = 200)

    val particleSystem = ParticleSystem(maxParticles = 4000)

    val playback = PlaybackController(
        fps = project.fps,
        loopMode = PlaybackController.LoopMode.Loop,
        frameRange = 0..project.frameCount
    )

    /**
     * New crash-safe playback engine. Drives the frame loop on
     * Dispatchers.Default and exposes [PlaybackEngine.currentFrame] as a
     * StateFlow that the UI collects on Main.
     *
     * The legacy [playback] (PlaybackController) is kept for backward
     * compatibility with callers that read [PlaybackController.frameRange]
     * but is no longer driven by a coroutine.
     */
    val playbackEngine: PlaybackEngine = PlaybackEngine(
        project = project,
        particleSystem = particleSystem,
        springBoneSolvers = emptyList(),
    )

    val engineState: StateFlow<PlaybackEngine.State> = playbackEngine.state
    val engineCurrentFrame: StateFlow<Int> = playbackEngine.currentFrame
    val engineFps: StateFlow<Int> = playbackEngine.fps

    val macroEngine = com.devxan.proanimation.engine.export.MacroEngine()

    private val _activeLayer = MutableStateFlow<Layer?>(null)
    val activeLayer: StateFlow<Layer?> = _activeLayer.asStateFlow()

    private val _currentFrame = MutableStateFlow(0)
    val currentFrame: StateFlow<Int> = _currentFrame.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _onionSkin = MutableStateFlow(OnionSkinConfig())
    val onionSkin: StateFlow<OnionSkinConfig> = _onionSkin.asStateFlow()

    private val _autoKeyframe = MutableStateFlow(true)
    val autoKeyframe: StateFlow<Boolean> = _autoKeyframe.asStateFlow()

    private val _fps = MutableStateFlow(60)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private val _selectedTool = MutableStateFlow(Tool.Select)
    val selectedTool: StateFlow<Tool> = _selectedTool.asStateFlow()

    private val _palette = MutableStateFlow(project.palette.toList())
    val palette: StateFlow<List<Int>> = _palette.asStateFlow()

    private val _issues = MutableLiveData<List<ProjectValidator.Issue>>(emptyList())
    val issues: LiveData<List<ProjectValidator.Issue>> = _issues

    private val _statusMessage = MutableLiveData<String>("Ready")
    val statusMessage: LiveData<String> = _statusMessage

    private var playbackJob: Job? = null  // legacy; kept for compatibility, no longer used
    private var frameSyncJob: Job? = null
    private var autosaveJob: Job? = null

    init {
        startAutosave()
        bridgeEngineToUi()
    }

    /**
     * Bridge the engine's currentFrame StateFlow into the legacy
     * [_currentFrame] used by the existing UI. Runs on Main to keep
     * Compose recomposition safe. Cancellation is automatic when the
     * ViewModel's viewModelScope is cleared.
     */
    private fun bridgeEngineToUi() {
        frameSyncJob = viewModelScope.launch(Dispatchers.Main) {
            try {
                playbackEngine.currentFrame.collect { engineFrame ->
                    if (engineFrame != _currentFrame.value) {
                        _currentFrame.value = engineFrame
                    }
                    _fps.value = playbackEngine.fps.value
                    // Sync the legacy isPlaying flag from the engine state machine.
                    when (playbackEngine.state.value) {
                        PlaybackEngine.State.PLAYING -> {
                            if (!_isPlaying.value) _isPlaying.value = true
                        }
                        PlaybackEngine.State.PAUSED -> {
                            if (_isPlaying.value) _isPlaying.value = false
                        }
                        PlaybackEngine.State.STOPPED -> {
                            if (_isPlaying.value) _isPlaying.value = false
                        }
                    }
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (t: Throwable) {
                android.util.Log.w("StudioViewModel", "Frame sync collector ended: ${t.message}")
            }
        }
    }

    enum class Tool {
        Select, Pen, Brush, Eraser, Rectangle, Ellipse, Polygon, Star, Spiral,
        NodeEdit, Eyedropper, Bone, IK, Hand, Zoom
    }

    // ── Project operations ─────────────────────────────────────────────────

    fun newProject(name: String = "Untitled Project", width: Int = 1920, height: Int = 1080, fps: Int = 24) {
        project.name = name
        project.canvasWidth = width
        project.canvasHeight = height
        project.fps = fps
        project.frameCount = 240
        project.layers.clear()
        project.skeletons.clear()
        playback.fps = fps
        playback.frameRange = 0..project.frameCount
        _activeLayer.value = null
        _currentFrame.value = 0
        _statusMessage.value = "New project created"
        validate()
    }

    fun saveProject(output: File) {
        try {
            FileOutputStream(output).use { serializer.save(project, it) }
            _statusMessage.value = "Saved ${output.name}"
        } catch (e: Exception) {
            _statusMessage.value = "Save failed: ${e.message}"
        }
    }

    fun loadProject(input: File) {
        try {
            val loaded = input.inputStream().use { serializer.load(it) }
            project.layers.clear(); project.layers.addAll(loaded.layers)
            project.skeletons.clear(); project.skeletons.putAll(loaded.skeletons)
            project.fps = loaded.fps; project.frameCount = loaded.frameCount
            project.canvasWidth = loaded.canvasWidth; project.canvasHeight = loaded.canvasHeight
            project.palette.clear(); project.palette.addAll(loaded.palette)
            playback.fps = project.fps
            playback.frameRange = 0..project.frameCount
            _statusMessage.value = "Loaded ${loaded.name}"
            validate()
        } catch (e: Exception) {
            _statusMessage.value = "Load failed: ${e.message}"
        }
    }

    // ── Layer operations ───────────────────────────────────────────────────

    fun addVectorLayer(name: String = "Vector ${project.layers.size + 1}") {
        val layer = Layer.Vector(name = name)
        undoStack.push(object : Command {
            override val description = "Add layer '$name'"
            override fun execute() { project.layers.add(layer); _activeLayer.value = layer }
            override fun undo() { project.layers.remove(layer); _activeLayer.value = null }
        })
    }

    fun addImageLayer(uri: Uri, name: String = "Image") {
        val layer = Layer.Image(name = name, sourceUri = uri.toString(), bitmapRef = uri.toString())
        undoStack.push(object : Command {
            override val description = "Add image layer"
            override fun execute() { project.layers.add(layer); _activeLayer.value = layer }
            override fun undo() { project.layers.remove(layer); _activeLayer.value = null }
        })
    }

    fun addGroupLayer(name: String = "Group") {
        val layer = Layer.Group(name = name)
        undoStack.push(object : Command {
            override val description = "Add group"
            override fun execute() { project.layers.add(layer) }
            override fun undo() { project.layers.remove(layer) }
        })
    }

    fun addSwitchLayer(name: String = "Switch") {
        val layer = Layer.Switch(name = name)
        undoStack.push(object : Command {
            override val description = "Add switch layer"
            override fun execute() { project.layers.add(layer) }
            override fun undo() { project.layers.remove(layer) }
        })
    }

    fun addParticleLayer(name: String = "Particles") {
        val layer = Layer.Particle(name = name)
        undoStack.push(object : Command {
            override val description = "Add particle layer"
            override fun execute() { project.layers.add(layer) }
            override fun undo() { project.layers.remove(layer) }
        })
    }

    fun deleteLayer(layer: Layer) {
        undoStack.push(object : Command {
            override val description = "Delete layer '${layer.name}'"
            override fun execute() {
                project.layers.remove(layer)
                if (_activeLayer.value === layer) _activeLayer.value = null
            }
            override fun undo() { project.layers.add(layer) }
        })
    }

    fun selectLayer(layer: Layer?) { _activeLayer.value = layer }

    fun setLayerOpacity(layer: Layer, opacity: Float) {
        val old = layer.opacity
        undoStack.push(PropertyCommand(
            description = "Set opacity",
            getter = { layer.opacity },
            setter = { layer.opacity = it },
            newValue = opacity.coerceIn(0f, 1f),
            mergeable = true,
            shouldMerge = { _, _ -> true }
        ))
    }

    fun setLayerBlendMode(layer: Layer, mode: Layer.BlendMode) {
        val old = layer.blendMode
        undoStack.push(object : Command {
            override val description = "Set blend mode"
            override fun execute() { layer.blendMode = mode }
            override fun undo() { layer.blendMode = old }
        })
    }

    fun setLayerVisibility(layer: Layer, visible: Boolean) {
        val old = layer.visible
        undoStack.push(object : Command {
            override val description = "Toggle visibility"
            override fun execute() { layer.visible = visible }
            override fun undo() { layer.visible = old }
        })
    }

    fun duplicateLayer(layer: Layer) {
        val copy = when (layer) {
            is Layer.Vector -> layer.copy(name = layer.name + " copy")
            is Layer.Image -> layer.copy(name = layer.name + " copy")
            is Layer.Group -> layer.copy(name = layer.name + " copy")
            is Layer.Switch -> layer.copy(name = layer.name + " copy")
            is Layer.Particle -> layer.copy(name = layer.name + " copy")
            is Layer.Mask -> layer.copy(name = layer.name + " copy")
        }
        undoStack.push(object : Command {
            override val description = "Duplicate layer"
            override fun execute() { project.layers.add(copy) }
            override fun undo() { project.layers.remove(copy) }
        })
    }

    fun mergeLayers(a: Layer.Vector, b: Layer.Vector) {
        // For vector layers: union their paths
        if (a.paths.isEmpty() || b.paths.isEmpty()) return
        val resultPath = PathBooleanOps.operate(
            a.paths.first().path, b.paths.first().path, PathBooleanOps.Op.Union)
        undoStack.push(object : Command {
            override val description = "Merge layers"
            override fun execute() {
                a.paths.first().path.reset(); a.paths.first().path.add(resultPath)
                project.layers.remove(b)
            }
            override fun undo() { /* best-effort: not fully reversible */ }
        })
    }

    // ── Tool selection ─────────────────────────────────────────────────────

    fun setTool(tool: Tool) { _selectedTool.value = tool }

    // ── Timeline / keyframe ────────────────────────────────────────────────

    fun setCurrentFrame(frame: Int) {
        val clamped = frame.coerceIn(0, (project.frameCount - 1).coerceAtLeast(0))
        _currentFrame.value = clamped
        playbackEngine.seek(clamped)
        audioEngine.seekToFrame(clamped, project.fps)
    }

    /**
     * Start playback. Delegates to [PlaybackEngine.play] which spins up the
     * frame loop on Dispatchers.Default.
     *
     * Crash fixes vs the previous implementation:
     *   - No coroutine launched on Dispatchers.Main with delay(8L).
     *   - Engine owns its own Job; pause()/stop()/release() cancel cleanly.
     *   - Loop body is fully wrapped in try/catch with a back-off policy.
     *   - Frame indices are clamped before emission; FPS calc is guarded
     *     against division by zero.
     */
    fun play() {
        if (_isPlaying.value) return
        if (project.frameCount <= 0) {
            _statusMessage.value = "Cannot play: project has no frames"
            return
        }
        _isPlaying.value = true
        playbackEngine.play()
        audioEngine.play()
    }

    fun pause() {
        if (!_isPlaying.value) return
        _isPlaying.value = false
        playbackEngine.pause()
        audioEngine.pause()
    }

    fun stop() {
        _isPlaying.value = false
        playbackEngine.stop()
        audioEngine.pause()
        _currentFrame.value = playbackEngine.currentFrame.value
    }

    fun toggleOnionSkin() { _onionSkin.value = _onionSkin.value.copy(enabled = !_onionSkin.value.enabled) }
    fun toggleAutoKeyframe() { _autoKeyframe.value = !_autoKeyframe.value }
    fun setFps(fps: Int) {
        project.fps = fps
        playback.fps = fps
    }

    fun addKeyframe(targetId: String, channel: String, frame: Int, value: Keyframe.KeyframeValue) {
        val kf = Keyframe(frame = frame, value = value, interpolation = Keyframe.Interpolation.Bezier())
        project.timeline.setKeyframe(targetId, channel, kf)
        _statusMessage.value = "Keyframe added at frame $frame"
    }

    fun removeKeyframe(targetId: String, channel: String, frame: Int) {
        project.timeline.removeKeyframe(targetId, channel, frame)
    }

    fun batchMoveKeyframes(targetId: String, channel: String, frameDelta: Int) {
        val list = project.timeline.keyframes(targetId, channel).toMutableList()
        list.forEachIndexed { i, kf ->
            project.timeline.removeKeyframe(targetId, channel, kf.frame)
            project.timeline.setKeyframe(targetId, channel, kf.copy(frame = kf.frame + frameDelta))
        }
    }

    // ── Undo / redo ────────────────────────────────────────────────────────

    fun undo() { undoStack.undo() }
    fun redo() { undoStack.redo() }

    // ── File importers ─────────────────────────────────────────────────────

    fun importStk(uri: Uri, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val entry = project.figureLibrary.importStk(getApplication<DevxanApplication>()
                    .contentResolver.openInputStream(uri)!!, name)
                _statusMessage.postValue("Imported figure '$name' (v${entry.pivotVersion})")
            } catch (e: Exception) {
                _statusMessage.postValue("Import failed: ${e.message}")
            }
        }
    }

    fun importPiv(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = getApplication<DevxanApplication>().contentResolver.openInputStream(uri)!!
                project.figureLibrary.importPiv(stream, project) { err ->
                    _statusMessage.postValue(err)
                }
                _statusMessage.postValue("Imported .piv with ${project.figureLibrary.size()} figures")
                validate()
            } catch (e: Exception) {
                _statusMessage.postValue("Piv import failed: ${e.message}")
            }
        }
    }

    // ── Audio ──────────────────────────────────────────────────────────────

    fun addAudioTrack(uri: Uri, name: String, startFrame: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val track = audioEngine.addTrack(uri, name, startFrame, project.fps)
            if (track != null) {
                project.audioTracks.add(track)
                _statusMessage.postValue("Added audio track '$name'")
            } else {
                _statusMessage.postValue("Failed to add audio")
            }
        }
    }

    fun setAudioVolume(track: AudioTrackRef, volume: Float) {
        audioEngine.setVolume(track, volume)
    }

    // ── Validation ────────────────────────────────────────────────────────

    fun validate() {
        _issues.value = validator.validate(project)
    }

    // ── Autosave ───────────────────────────────────────────────────────────

    private fun startAutosave() {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                delay(60_000L)
                appRef.crashRecovery.snapshot(project)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Stop the playback engine FIRST so the worker coroutine doesn't keep
        // emitting to a dead StateFlow collector.
        playbackEngine.release()
        playbackJob?.cancel()
        frameSyncJob?.cancel()
        autosaveJob?.cancel()
        audioEngine.stop()
    }
}
