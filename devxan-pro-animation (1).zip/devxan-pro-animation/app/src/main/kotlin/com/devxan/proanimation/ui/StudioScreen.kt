package com.devxan.proanimation.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.livedata.observeAsState
import java.io.File
import java.io.FileOutputStream
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.ui.canvas.CanvasViewport
import com.devxan.proanimation.ui.panels.FigureLibraryPanel
import com.devxan.proanimation.ui.panels.LayersPanel
import com.devxan.proanimation.ui.panels.PropertiesPanel
import com.devxan.proanimation.ui.panels.ColorPanel
import com.devxan.proanimation.ui.timeline.TimelinePanel
import com.devxan.proanimation.ui.toolbar.Toolbar
import com.devxan.proanimation.viewmodel.StudioViewModel
import com.devxan.proanimation.ui.theme.*

/**
 * The main studio screen. Responsive layout:
 *
 *   - Phone portrait (< 600dp):  Side panels HIDDEN by default, toggle via buttons.
 *                                Canvas takes full width. Timeline collapsed by default.
 *   - Phone landscape / small tablet (600-900dp):
 *                                One side panel visible at a time (tabbed).
 *                                Canvas takes most of the screen.
 *   - Tablet (≥ 900dp):           Both side panels visible (240dp each).
 *                                Canvas takes the remaining width.
 *
 * Top toolbar: tool palette + playback + panel toggle buttons.
 * Bottom: collapsible timeline (240dp tall when expanded, 36dp when collapsed).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(intent: Intent?) {
    val vm: StudioViewModel = viewModel()
    val isPlaying by vm.isPlaying.collectAsState()
    val currentFrame by vm.currentFrame.collectAsState()
    val activeLayer by vm.activeLayer.collectAsState()
    val selectedTool by vm.selectedTool.collectAsState()
    val onionSkin by vm.onionSkin.collectAsState()
    val autoKey by vm.autoKeyframe.collectAsState()
    val fps by vm.fps.collectAsState()
    val palette by vm.palette.collectAsState()
    val status by vm.statusMessage.observeAsState("Ready")
    val issues by vm.issues.observeAsState(emptyList())
    val frameCount = vm.project.frameCount

    // Responsive state — panel visibility per screen size class
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val isCompact = screenWidthDp < 600
    val isMedium = screenWidthDp in 600..900

    var leftPanelVisible by remember(screenWidthDp) { mutableStateOf(!isCompact) }
    var rightPanelVisible by remember(screenWidthDp) { mutableStateOf(!isCompact && !isMedium) }
    var timelineExpanded by remember { mutableStateOf(true) }
    var showImportSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // File launchers
    val openStkLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importStk(it, "imported_figure") } }

    val openPivLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importPiv(it) } }

    val openProjectLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                val tempFile = File(ctx.cacheDir, "loaded.dxproj")
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { input.copyTo(it) }
                }
                vm.loadProject(tempFile)
            } catch (e: Exception) { /* ignore */ }
        }
    }

    val createDocLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        uri?.let {
            try {
                val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                val tempFile = File(ctx.cacheDir, "save.dxproj")
                vm.saveProject(tempFile)
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    tempFile.inputStream().use { it.copyTo(out) }
                }
            } catch (_: Exception) {}
        }
    }

    // Handle incoming VIEW intents
    LaunchedEffect(intent) {
        intent?.data?.let { uri ->
            val name = uri.lastPathSegment ?: "imported"
            when {
                name.endsWith(".stk", ignoreCase = true) -> vm.importStk(uri, name)
                name.endsWith(".piv", ignoreCase = true) -> vm.importPiv(uri)
                name.endsWith(".dxproj", ignoreCase = true) -> {
                    val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                    val tempFile = File(ctx.cacheDir, "intent.dxproj")
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { input.copyTo(it) }
                    }
                    vm.loadProject(tempFile)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DEVXAN PRO ANIMATION", fontWeight = FontWeight.Bold, color = DarkPrimary) },
                navigationIcon = {
                    IconButton(onClick = { showImportSheet = true }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Open")
                    }
                },
                actions = {
                    // Panel toggle buttons — let user show/hide side panels
                    IconButton(onClick = { leftPanelVisible = !leftPanelVisible }) {
                        Icon(
                            if (leftPanelVisible) Icons.Default.ViewSidebar else Icons.Default.SidebarOff,
                            contentDescription = "Toggle left panel",
                            tint = if (leftPanelVisible) DarkPrimary else DarkMuted
                        )
                    }
                    IconButton(onClick = { rightPanelVisible = !rightPanelVisible }) {
                        Icon(
                            if (rightPanelVisible) Icons.Default.ViewSidebar else Icons.Default.SidebarOff,
                            contentDescription = "Toggle right panel",
                            tint = if (rightPanelVisible) DarkSecondary else DarkMuted
                        )
                    }
                    IconButton(onClick = { timelineExpanded = !timelineExpanded }) {
                        Icon(
                            if (timelineExpanded) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
                            contentDescription = "Toggle timeline",
                            tint = if (timelineExpanded) DarkTertiary else DarkMuted
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { vm.undo() }) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { vm.redo() }) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    IconButton(onClick = { createDocLauncher.launch(arrayOf("application/zip")) }) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                    }
                    IconButton(onClick = { showExportSheet = true }) {
                        Icon(Icons.Default.VideoFile, contentDescription = "Export")
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = DarkPrimary
                )
            )
        },
        bottomBar = {
            StatusBar(status = status, fps = fps, frame = currentFrame, total = frameCount, issues = issues)
        }
    ) { padding ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(DarkBackground)) {

            // Toolbar (tool palette + playback)
            Toolbar(
                selectedTool = selectedTool,
                onToolSelected = { vm.setTool(it) },
                isPlaying = isPlaying,
                onPlayPause = { if (isPlaying) vm.pause() else vm.play() },
                onStop = { vm.stop() },
                onPrev = { vm.setCurrentFrame((currentFrame - 1).coerceAtLeast(0)) },
                onNext = { vm.setCurrentFrame((currentFrame + 1).coerceAtMost(frameCount - 1)) },
                onFirst = { vm.setCurrentFrame(0) },
                onLast = { vm.setCurrentFrame(frameCount - 1) },
                onionSkinEnabled = onionSkin.enabled,
                onToggleOnionSkin = { vm.toggleOnionSkin() },
                autoKeyframe = autoKey,
                onToggleAutoKeyframe = { vm.toggleAutoKeyframe() }
            )

            // Main work area: [left panel] | [canvas] | [right panel]
            // Side panels are 240dp wide (down from 280dp) and collapsible.
            // Canvas always takes the remaining space — this gives the user
            // maximum animation editing area on every screen size.
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                // ── Left panel (collapsible) ────────────────────────────────
                AnimatedVisibility(
                    visible = leftPanelVisible,
                    enter = fadeIn(), exit = fadeOut()
                ) {
                    Row(modifier = Modifier.width(240.dp).fillMaxHeight()) {
                        LeftPanelTabs(
                            modifier = Modifier.fillMaxSize().background(DarkSurface),
                            vm = vm
                        )
                        // Drag handle / collapse button — visible only when panel is open
                        Surface(
                            color = DarkSurfaceAlt,
                            modifier = Modifier.width(8.dp).fillMaxHeight()
                                .clickable { leftPanelVisible = false }
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.ChevronLeft,
                                    contentDescription = "Hide panel",
                                    tint = DarkMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }

                // ── Canvas viewport (always visible, fills remaining space) ─
                CanvasViewport(
                    vm = vm,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )

                // ── Right panel (collapsible) ───────────────────────────────
                AnimatedVisibility(
                    visible = rightPanelVisible,
                    enter = fadeIn(), exit = fadeOut()
                ) {
                    Row(modifier = Modifier.width(240.dp).fillMaxHeight()) {
                        // Collapse handle
                        Surface(
                            color = DarkSurfaceAlt,
                            modifier = Modifier.width(8.dp).fillMaxHeight()
                                .clickable { rightPanelVisible = false }
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = "Hide panel",
                                    tint = DarkMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        RightPanelTabs(
                            modifier = Modifier.fillMaxSize().background(DarkSurface),
                            vm = vm,
                            palette = palette
                        )
                    }
                }
            }

            // ── Bottom timeline (collapsible) ───────────────────────────────
            // When collapsed: only 36dp tall (shows ruler + playhead).
            // When expanded: 240dp tall (full track view).
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
            ) {
                // Tiny collapse/expand strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(DarkSurfaceAlt)
                        .clickable { timelineExpanded = !timelineExpanded }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (timelineExpanded) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
                        contentDescription = "Toggle timeline",
                        tint = DarkMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (timelineExpanded) "Timeline (tap to collapse)" else "Timeline (tap to expand)",
                        color = DarkMuted,
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Frame $currentFrame / $frameCount",
                        color = DarkPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                // Timeline body — only when expanded
                if (timelineExpanded) {
                    TimelinePanel(vm = vm, modifier = Modifier.height(212.dp).fillMaxWidth())
                }
            }
        }
    }

    if (showImportSheet) {
        ModalBottomSheet(onDismissRequest = { showImportSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                ListItem(
                    headlineContent = { Text("Import .stk Figure") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openStkLauncher.launch(arrayOf("*/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text("Import .piv Animation") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openPivLauncher.launch(arrayOf("*/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text("Open .dxproj Project") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openProjectLauncher.launch(arrayOf("application/zip", "*/*"))
                    }
                )
            }
        }
    }

    if (showExportSheet) {
        ModalBottomSheet(onDismissRequest = { showExportSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                ListItem(
                    headlineContent = { Text("Export MP4 (H.264)") },
                    supportingContent = { Text("Hardware-encoded, up to 4K") }
                )
                ListItem(
                    headlineContent = { Text("Export PNG Sequence") },
                    supportingContent = { Text("Per-frame PNGs for compositing") }
                )
                ListItem(
                    headlineContent = { Text("Export Audio Mix") },
                    supportingContent = { Text("OPUS / MP3 / AAC") }
                )
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("OK") } },
            title = { Text("Project Settings") },
            text = {
                Column {
                    Text("FPS: ${vm.project.fps}")
                    Text("Resolution: ${vm.project.canvasWidth}×${vm.project.canvasHeight}")
                    Text("Frames: ${vm.project.frameCount}")
                    Text("Layers: ${vm.project.layers.size}")
                    Text("Skeletons: ${vm.project.skeletons.size}")
                    Text("Figures in library: ${vm.project.figureLibrary.size()}")
                    Spacer(Modifier.height(8.dp))
                    Text("Screen width: $screenWidthDp dp (${if (isCompact) "compact" else if (isMedium) "medium" else "expanded"})",
                        color = DarkMuted, fontSize = 11.sp)
                }
            }
        )
    }
}

@Composable
private fun LeftPanelTabs(modifier: Modifier, vm: StudioViewModel) {
    var tab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Layers", "Figures", "Actions")
    Column(modifier) {
        TabRow(selectedTabIndex = tab, containerColor = DarkSurfaceAlt) {
            tabTitles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, fontSize = 10.sp) })
            }
        }
        when (tab) {
            0 -> LayersPanel(vm)
            1 -> FigureLibraryPanel(vm)
            2 -> ActionsPanel(vm)
        }
    }
}

@Composable
private fun RightPanelTabs(modifier: Modifier, vm: StudioViewModel, palette: List<Int>) {
    var tab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Properties", "Color", "Audio")
    Column(modifier) {
        TabRow(selectedTabIndex = tab, containerColor = DarkSurfaceAlt) {
            tabTitles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, fontSize = 10.sp) })
            }
        }
        when (tab) {
            0 -> PropertiesPanel(vm)
            1 -> ColorPanel(palette = palette)
            2 -> AudioPanel(vm)
        }
    }
}

@Composable
private fun ActionsPanel(vm: StudioViewModel) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        item { Text("Action Library", color = DarkPrimary, fontWeight = FontWeight.Bold) }
        item { Spacer(Modifier.height(8.dp)) }
        item { ActionButton("New Vector Layer") { vm.addVectorLayer() } }
        item { ActionButton("New Group") { vm.addGroupLayer() } }
        item { ActionButton("New Switch Layer") { vm.addSwitchLayer() } }
        item { ActionButton("New Particle Layer") { vm.addParticleLayer() } }
        item { Spacer(Modifier.height(8.dp)) }
        item { Text("Scripting", color = DarkPrimary, fontWeight = FontWeight.Bold) }
        item { ActionButton("Record Macro") { } }
        item { ActionButton("Play Macro") { } }
        item { Text("Recorded actions: ${vm.macroEngine.count()}", color = DarkMuted, fontSize = 10.sp) }
    }
}

@Composable
private fun ActionButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(text, fontSize = 11.sp)
    }
}

@Composable
private fun AudioPanel(vm: StudioViewModel) {
    val ctx = LocalContext.current
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.addAudioTrack(it, uri.lastPathSegment ?: "audio", 0) }
    }
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("Audio Tracks", color = DarkPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("+ Add Audio Track", fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        vm.project.audioTracks.forEach { track ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Text(track.name, color = DarkOnBackground, fontSize = 11.sp)
                    Text("Frames ${track.startFrame}-${track.endFrame}",
                        color = DarkMuted, fontSize = 10.sp)
                    Slider(
                        value = track.volume,
                        onValueChange = { vm.setAudioVolume(track, it) },
                        valueRange = 0f..2f
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBar(
    status: String,
    fps: Int,
    frame: Int,
    total: Int,
    issues: List<com.devxan.proanimation.engine.project.ProjectValidator.Issue>
) {
    Surface(color = DarkSurfaceAlt, tonalElevation = 2.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(status, color = DarkMuted, fontSize = 11.sp,
                modifier = Modifier.weight(1f).padding(end = 8.dp))
            if (issues.isNotEmpty()) {
                val errors = issues.count {
                    it.severity == com.devxan.proanimation.engine.project.ProjectValidator.Severity.Error
                }
                if (errors > 0) {
                    Icon(Icons.Default.Warning, contentDescription = "Issues", tint = DarkError,
                         modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("$errors errors", color = DarkError, fontSize = 11.sp)
                    Spacer(Modifier.width(12.dp))
                }
            }
            Text("Frame: $frame / $total", color = DarkOnBackground, fontSize = 11.sp)
            Spacer(Modifier.width(12.dp))
            Text("FPS: $fps", color = DarkPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}
