package com.devxan.proanimation.ui.canvas

import android.view.SurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devxan.proanimation.data.models.BezierPath
import com.devxan.proanimation.data.models.Vec2
import com.devxan.proanimation.engine.render.NativeRenderer
import com.devxan.proanimation.ui.theme.DarkBackground
import com.devxan.proanimation.ui.theme.DarkMuted
import com.devxan.proanimation.ui.theme.DarkPrimary
import com.devxan.proanimation.ui.theme.DarkSecondary
import com.devxan.proanimation.viewmodel.StudioViewModel
import kotlin.math.cos
import kotlin.math.sin

/**
 * Canvas viewport. Currently a Compose Canvas overlay (CPU-side) with the
 * native renderer initialized lazily for the OpenGL ES pipeline (used when
 * the user enables GPU acceleration in Settings).
 *
 * Touch gestures:
 *   - Single-finger drag: depending on the active tool (draw, paint, drag bone)
 *   - Pinch: zoom & pan the canvas
 *   - Long press: contextual menu (node edit, snap options)
 */
@Composable
fun CanvasViewport(vm: StudioViewModel, modifier: Modifier) {
    val project = vm.project
    val activeLayer by vm.activeLayer.collectAsState()
    val currentFrame by vm.currentFrame.collectAsState()
    val selectedTool by vm.selectedTool.collectAsState()
    val onionSkin by vm.onionSkin.collectAsState()
    var viewTransform = remember { androidx.compose.ui.geometry.Rect(0f, 0f, 1920f, 1080f) }
    var pan by remember { androidx.compose.runtime.mutableStateOf(Offset.Zero) }
    var zoom by remember { androidx.compose.runtime.mutableStateOf(1f) }

    Box(modifier = modifier.background(DarkBackground)) {
        Canvas(modifier = Modifier.fillMaxSize().pointerInput(Unit) {
            detectTransformGestures { _, panChange, zoomChange, _ ->
                pan += panChange
                zoom = (zoom * zoomChange).coerceIn(0.1f, 8f)
            }
        }.pointerInput(Unit) {
            detectTapGestures(onTap = { tap ->
                // Tool-specific tap handling
                when (selectedTool) {
                    StudioViewModel.Tool.Pen -> vm.addKeyframe(
                        "active_layer", "position", currentFrame,
                        com.devxan.proanimation.data.models.Keyframe.KeyframeValue.Vec2V(
                            Vec2(tap.x - pan.x, tap.y - pan.y))
                    )
                    StudioViewModel.Tool.Select -> {
                        // Pick a layer at this point
                    }
                    else -> {}
                }
            })
        }) {
            // Wrap the entire render block in CrashGuard so any exception
            // in draw helpers (NaN transform, missing skeleton, empty path...)
            // is swallowed and the next frame is attempted instead of
            // crashing Compose's draw phase.
            com.devxan.proanimation.engine.animation.CrashGuard.safe {
                // Draw canvas background grid
                drawGrid(zoom, pan)

                // Defensive snapshot of layers so ConcurrentModificationException
                // is impossible even if the user adds/removes a layer mid-frame.
                val visibleLayers = com.devxan.proanimation.engine.animation.FrameValidator
                    .safeFrame(project, currentFrame).layers

                // Draw all visible layers
                for (layer in visibleLayers) {
                    if (!runCatching { layer.visible }.getOrDefault(false)) continue
                    runCatching {
                        when (layer) {
                            is com.devxan.proanimation.data.models.Layer.Vector -> drawVectorLayer(layer, currentFrame, vm)
                            is com.devxan.proanimation.data.models.Layer.Image -> drawImageLayer(layer)
                            is com.devxan.proanimation.data.models.Layer.Group -> {}
                            is com.devxan.proanimation.data.models.Layer.Switch -> {}
                            is com.devxan.proanimation.data.models.Layer.Particle -> drawParticleLayer(layer, vm)
                            is com.devxan.proanimation.data.models.Layer.Mask -> {}
                        }
                    }
                }

                // Draw bone overlay if the active layer has a skeleton
                activeLayer?.let { layer ->
                    runCatching {
                        if (layer is com.devxan.proanimation.data.models.Layer.Vector) {
                            val skeletonId = layer.skeletonId ?: return@runCatching
                            val skel = com.devxan.proanimation.engine.animation.FrameValidator
                                .safeSkeleton(project, skeletonId) ?: return@runCatching
                            drawSkeletonOverlay(skel, currentFrame, vm)
                        }
                    }
                }

                // Draw onion skins
                if (onionSkin.enabled) {
                    runCatching {
                        drawOnionSkins(currentFrame, onionSkin.pastFrames, onionSkin.futureFrames, vm)
                    }
                }
            } // end CrashGuard.safe
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGrid(zoom: Float, pan: Offset) {
    val gridSize = 100f * zoom
    val left = (pan.x % gridSize).coerceIn(-gridSize, 0f)
    val top  = (pan.y % gridSize).coerceIn(-gridSize, 0f)
    var x = left
    while (x < size.width) {
        drawLine(DarkMuted.copy(alpha = 0.15f),
            Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
        x += gridSize
    }
    var y = top
    while (y < size.height) {
        drawLine(DarkMuted.copy(alpha = 0.15f),
            Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        y += gridSize
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawVectorLayer(
    layer: com.devxan.proanimation.data.models.Layer.Vector,
    frame: Int,
    vm: StudioViewModel
) {
    // Take a defensive copy of the path list to avoid CME during iteration
    val pathSnapshot = runCatching { layer.paths.toList() }.getOrDefault(emptyList())
    if (pathSnapshot.isEmpty()) return
    val evaluator = com.devxan.proanimation.engine.animation.AnimationEvaluator(vm.project.timeline)
    for (pathObj in pathSnapshot) {
        val commands = runCatching { pathObj.path.commands() }.getOrDefault(emptyList())
        if (commands.isEmpty()) continue
        val p = Path()
        for (cmd in commands) {
            when (cmd.type) {
                BezierPath.CommandType.MoveTo -> p.moveTo(cmd.x1, cmd.y1)
                BezierPath.CommandType.LineTo -> p.lineTo(cmd.x1, cmd.y1)
                BezierPath.CommandType.QuadTo -> p.quadraticTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2)
                BezierPath.CommandType.CubicTo -> p.cubicTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2, cmd.x3, cmd.y3)
                BezierPath.CommandType.Close -> p.close()
            }
        }
        when (val fill = pathObj.fill) {
            is com.devxan.proanimation.data.models.FillStyle.Solid -> {
                drawPath(p, color = Color(fill.color.argb).copy(alpha = layer.opacity))
            }
            is com.devxan.proanimation.data.models.FillStyle.LinearGradient,
            is com.devxan.proanimation.data.models.FillStyle.RadialGradient,
            is com.devxan.proanimation.data.models.FillStyle.Pattern -> {
                drawPath(p, color = Color.White.copy(alpha = layer.opacity * 0.3f))
            }
            com.devxan.proanimation.data.models.FillStyle.None -> {}
        }
        if (pathObj.stroke.color.argb != 0) {
            drawPath(p, color = Color(pathObj.stroke.color.argb).copy(alpha = layer.opacity),
                style = Stroke(width = pathObj.stroke.width))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawImageLayer(
    layer: com.devxan.proanimation.data.models.Layer.Image
) {
    // Placeholder rectangle for image layer bounds
    drawRect(
        color = DarkMuted.copy(alpha = 0.2f),
        topLeft = Offset(layer.transform.position.x, layer.transform.position.y),
        size = androidx.compose.ui.geometry.Size(400f, 300f)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawParticleLayer(
    layer: com.devxan.proanimation.data.models.Layer.Particle,
    vm: StudioViewModel
) {
    // Cap visible particles to prevent Compose draw phase from stalling on a
    // 4000-particle system snapshot every frame.
    val particles = runCatching { vm.particleSystem.snapshot() }.getOrDefault(emptyList())
    val maxDraw = 500  // safety cap
    var drawn = 0
    for (p in particles) {
        if (drawn >= maxDraw) break
        if (p.x.isNaN() || p.y.isNaN() || p.size.isNaN()) continue
        val alpha = runCatching { vm.particleSystem.particleAlpha(p) }.getOrDefault(0f)
        drawCircle(
            color = DarkSecondary.copy(alpha = alpha * layer.opacity),
            radius = p.size.coerceAtLeast(0.5f),
            center = Offset(p.x, p.y)
        )
        drawn++
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSkeletonOverlay(
    skeleton: com.devxan.proanimation.data.models.Skeleton,
    frame: Int,
    vm: StudioViewModel
) {
    if (skeleton.size == 0) return  // empty skeleton - draw nothing
    // FK solve can throw if bone.parentIndex points out of range due to
    // an in-progress edit; fall back to an empty pose list in that case.
    val poses = runCatching {
        com.devxan.proanimation.data.models.ForwardKinematics(skeleton).solve()
    }.getOrDefault(emptyList())
    for (pose in poses) {
        // Skip NaN/Inf positions that would crash Skia's drawLine.
        if (pose.headWorld.x.isNaN() || pose.headWorld.y.isNaN()) continue
        if (pose.tailWorld.x.isNaN() || pose.tailWorld.y.isNaN()) continue
        drawLine(
            DarkPrimary,
            start = Offset(pose.headWorld.x, pose.headWorld.y),
            end = Offset(pose.tailWorld.x, pose.tailWorld.y),
            strokeWidth = 4f
        )
        drawCircle(DarkSecondary, radius = 6f, center = Offset(pose.headWorld.x, pose.headWorld.y))
        drawCircle(DarkSecondary, radius = 4f, center = Offset(pose.tailWorld.x, pose.tailWorld.y))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawOnionSkins(
    currentFrame: Int,
    pastFrames: Int,
    futureFrames: Int,
    vm: StudioViewModel
) {
    for (i in 1..pastFrames) {
        val frame = (currentFrame - i).coerceAtLeast(0)
        val alpha = 0.4f * (1f - i.toFloat() / (pastFrames + 1))
        for (layer in vm.project.layers) {
            if (layer !is com.devxan.proanimation.data.models.Layer.Vector) continue
            for (pathObj in layer.paths) {
                val p = Path()
                for (cmd in pathObj.path.commands()) {
                    when (cmd.type) {
                        BezierPath.CommandType.MoveTo -> p.moveTo(cmd.x1, cmd.y1)
                        BezierPath.CommandType.LineTo -> p.lineTo(cmd.x1, cmd.y1)
                        BezierPath.CommandType.QuadTo -> p.quadraticTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2)
                        BezierPath.CommandType.CubicTo -> p.cubicTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2, cmd.x3, cmd.y3)
                        BezierPath.CommandType.Close -> p.close()
                    }
                }
                drawPath(p, Color(0xFFE5A4FF.toInt()).copy(alpha = alpha), style = Stroke(width = 1f))
            }
        }
    }
    for (i in 1..futureFrames) {
        val frame = (currentFrame + i).coerceAtMost(vm.project.frameCount - 1)
        val alpha = 0.4f * (1f - i.toFloat() / (futureFrames + 1))
        for (layer in vm.project.layers) {
            if (layer !is com.devxan.proanimation.data.models.Layer.Vector) continue
            for (pathObj in layer.paths) {
                val p = Path()
                for (cmd in pathObj.path.commands()) {
                    when (cmd.type) {
                        BezierPath.CommandType.MoveTo -> p.moveTo(cmd.x1, cmd.y1)
                        BezierPath.CommandType.LineTo -> p.lineTo(cmd.x1, cmd.y1)
                        BezierPath.CommandType.QuadTo -> p.quadraticTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2)
                        BezierPath.CommandType.CubicTo -> p.cubicTo(cmd.x1, cmd.y1, cmd.x2, cmd.y2, cmd.x3, cmd.y3)
                        BezierPath.CommandType.Close -> p.close()
                    }
                }
                drawPath(p, Color(0xFF4FE3FF.toInt()).copy(alpha = alpha), style = Stroke(width = 1f))
            }
        }
    }
}
