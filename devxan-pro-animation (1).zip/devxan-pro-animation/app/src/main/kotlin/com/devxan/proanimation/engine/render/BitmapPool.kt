package com.devxan.proanimation.engine.render

import android.graphics.Bitmap
import android.graphics.Canvas
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * Bitmap pool for the playback / export render pipeline.
 *
 * Avoids per-frame Bitmap allocation (which causes GC churn and OOM on long
 * animations) by keeping a small queue of recycled bitmaps keyed on
 * (width, height). When a render pass needs a buffer, the pool returns a
 * reusable bitmap; when the render pass is done, it returns the buffer to
 * the pool instead of letting it be garbage-collected.
 *
 * Thread-safe. Memory ceiling enforced; excess buffers are recycled.
 */
class BitmapPool(private val maxBytes: Long = DEFAULT_MAX_BYTES) {

    private val pool = ConcurrentLinkedQueue<PooledBuffer>()
    private val totalBytes = AtomicLong(0L)

    @Synchronized
    fun acquire(width: Int, height: Int): PooledBuffer {
        if (width <= 0 || height <= 0) return PooledBuffer.EMPTY
        // Look for an exact-size match in the pool
        val iter = pool.iterator()
        while (iter.hasNext()) {
            val buf = iter.next()
            if (buf.bitmap.width == width && buf.bitmap.height == height && !buf.bitmap.isRecycled) {
                iter.remove()
                totalBytes.addAndGet(-buf.bitmap.byteCount.toLong())
                buf.bitmap.eraseColor(0) // clear alpha
                return buf
            }
        }
        // Allocate fresh
        return allocateNew(width, height)
    }

    private fun allocateNew(width: Int, height: Int): PooledBuffer {
        return try {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            PooledBuffer(bmp, canvas, this)
        } catch (oom: OutOfMemoryError) {
            // Evict everything and retry once
            clear()
            return try {
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                PooledBuffer(bmp, Canvas(bmp), this)
            } catch (oom2: OutOfMemoryError) {
                PooledBuffer.EMPTY
            }
        }
    }

    @Synchronized
    fun release(buf: PooledBuffer) {
        if (buf === PooledBuffer.EMPTY) return
        if (buf.bitmap.isRecycled) return
        val size = buf.bitmap.byteCount.toLong()
        if (totalBytes.get() + size > maxBytes) {
            buf.bitmap.recycle()
            return
        }
        totalBytes.addAndGet(size)
        pool.offer(buf)
    }

    fun clear() {
        synchronized(this) {
            pool.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
            pool.clear()
            totalBytes.set(0L)
        }
    }

    fun totalBytesUsed(): Long = totalBytes.get()

    companion object {
        const val DEFAULT_MAX_BYTES = 16L * 1024L * 1024L // 16 MB cap
    }
}

/**
 * One pooled bitmap + its paired Canvas. Call [release] to return it to the
 * pool; never call [Bitmap.recycle] directly.
 */
class PooledBuffer(
    val bitmap: Bitmap,
    val canvas: Canvas,
    private val pool: BitmapPool?,
) {
    fun release() { pool?.release(this) }

    companion object {
        // Sentinel: a 1x1 transparent bitmap used as a safe fallback.
        val EMPTY = run {
            val b = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            b.eraseColor(0)
            PooledBuffer(b, Canvas(b), pool = null)
        }
    }
}
