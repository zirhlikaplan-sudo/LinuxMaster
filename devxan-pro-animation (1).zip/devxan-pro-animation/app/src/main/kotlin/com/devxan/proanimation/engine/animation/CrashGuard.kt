package com.devxan.proanimation.engine.animation

import android.util.Log

/**
 * Defensive wrapper that catches any throwable escaping a render / playback
 * operation and prevents it from crashing the app.
 *
 * Errors are throttled: only the first [MAX_LOGGED] errors per
 * [ERROR_RESET_MS] window are logged to logcat. After that, the guard
 * silently swallows them but still returns the safe default. This keeps
 * logcat readable if a render path has a persistent bug.
 */
object CrashGuard {

    private const val TAG = "DevxanCrashGuard"
    private const val MAX_LOGGED = 12
    private const val ERROR_RESET_MS = 10_000L

    private var errorCount = 0
    private var lastErrorMs = 0L

    /** Run [block], returning [default] on any non-cancellation throwable. */
    fun <T> safe(default: T, block: () -> T): T = try {
        block()
    } catch (ce: kotlinx.coroutines.CancellationException) {
        throw ce
    } catch (t: Throwable) {
        logThrottled(t)
        default
    }

    /** Run [block]; return true on success, false on a swallowed throwable. */
    fun safe(block: () -> Unit): Boolean = try {
        block(); true
    } catch (ce: kotlinx.coroutines.CancellationException) {
        throw ce
    } catch (t: Throwable) {
        logThrottled(t); false
    }

    @Synchronized
    private fun logThrottled(t: Throwable) {
        val now = System.currentTimeMillis()
        if (now - lastErrorMs > ERROR_RESET_MS) errorCount = 0
        lastErrorMs = now
        errorCount++
        if (errorCount <= MAX_LOGGED) {
            Log.e(TAG, "Swallowed render/playback error #$errorCount", t)
        } else if (errorCount == MAX_LOGGED + 1) {
            Log.e(TAG, "Error threshold reached; suppressing further logs for $ERROR_RESET_MS ms")
        }
    }
}
